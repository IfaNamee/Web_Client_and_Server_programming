let randomCountryElement = document.querySelector('#random-country')
let userAnswerElement = document.querySelector('#user-answer')
let submitButton = document.querySelector('#submit-answer')
let resultTextElement = document.querySelector('#result')
let playAgainButton = document.querySelector('#play-again')

// Function to start the quiz with a new random country
function startQuiz() {

    let rade = countriesAndCodes[Math.floor(Math.random() * countriesAndCodes.length)]; // do select randem
    randomCountryElement.innerHTML = `${rade.name}` // Display the country's name in the page.
    let two_letter = rade["alpha-2"].toLowerCase() // get two letter from random selected.

    resultTextElement.innerHTML = '' // remove result place 

    // To get url for country selected by random.
    let url = 'https://api.worldbank.org/v2/country/'+ two_letter +'?format=json'

    // Fetch to request data and convert to json.
    fetch(url)
        .then( (res) => res.json())
        .then( (data) => {

        let countrieName = data[1][0].name  // get country name using arrays.
        let capitalCity = data[1][0].capitalCity // get capital city using arrays.

        submitButton.addEventListener( 'click', function () {

            // read capital city from user input. remove space before and after
            let inputCityName = userAnswerElement.value.trim()

            // Remove non letter from input
            inputCityName = inputCityName.replace(/[^a-zA-Z .']/g, "")
            
            // Varabile if a close enough match 
            let spelling = Levenshtein.get(inputCityName.toLowerCase(), capitalCity.toLowerCase());
            
            // Check if input is empty
            if (inputCityName === "") {
                resultTextElement.innerHTML = "Please enter an answer"
                resultTextElement.style.color = 'black'
                return // Stop if input is empty 

            } else if (inputCityName === capitalCity) {  // Check if input is same as capital city name.
                resultTextElement.innerHTML = 'Correct! The capital of ' + countrieName + ' is ' + inputCityName
                resultTextElement.style.color = "green"  // Text color

            } else if (spelling <= 2) {  // checks a close enough match with up to 2 characters miss
                resultTextElement.innerHTML = 'You\'re so close! The capital of ' + countrieName + ' is ' + capitalCity;
                resultTextElement.style.color = "gray";  // Text color for close match

            } else {   // Display is answer is wrong.
                resultTextElement.innerHTML = 'Wrong - the capital of ' + countrieName + ' is not ' + inputCityName + ', it is '  + capitalCity
                resultTextElement.style.color = "red";  // Text color 
            }

            })
            
            // Clear previous answer and result
            userAnswerElement.value = ''
            resultTextElement.innerHTML = ''
            
        }).catch((error) => {  // catch errors
            alert("ERROR fetching data ", error)
            })

        // Event listener for the Play Again button to start a new quiz round
        playAgainButton.addEventListener('click', startQuiz)

    }

startQuiz()

// TODO finish the script to challenge the user about their knowledge of capital cities.
// An array country names and two-letter country codes is provided in the countries.js file. 
// Your browser treats all JavaScript files included with script elements as one big file,
// organized in the order of the script tags. So the countriesAndCodes array from countries.js
// is available to this script.

// TODO when the page loads, select an element at random from the countriesAndCodes array  // DONE

// TODO display the country's name in the randomCountryElement  // DONE

// TODO add a click event handler to the submitButton.  When the user clicks the button,  // DONE
//  * read the text from the userAnswerElement  // DONE
//  * Use fetch() to make a call to the World Bank API with the two-letter country code (from countriesAndCodes, example 'CN' or 'AF')  // DONE
//  * Verify no errors were encountered in the API call. If an error occurs, display an alert message.   // DONE
//  * If the API call was successful, extract the capital city from the World Bank API response.  // DONE
//  * Compare the actual capital city to the user's answer.  // DONE
//      You can decide how correct you require the user to be. At the minimum, the user's answer should be the same // DONE
//      as the World Bank data - make the comparison case insensitive.  // Done
//      If you want to be more flexible, include and use a string similarity library such as https://github.com/hiddentao/fast-levenshtein 
//  * Finally, display an appropriate message in the resultTextElement to tell the user if they are right or wrong.  // DONE
//      For example 'Correct! The capital of Germany is Berlin' or 'Wrong - the capital of Germany is not G, it is Berlin' // DONE


// TODO finally, connect the play again button. Clear the user's answer, select a new random country, 
// display the country's name, handle the user's guess. If you didn't use functions in the code you've 
// already written, you should refactor your code to use functions to avoid writing very similar code twice. 
